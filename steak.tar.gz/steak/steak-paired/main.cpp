#include <iostream>
#include <fstream>
#include <boost/lexical_cast.hpp>
#include <string>
#include "samdata.hpp"
#include <vector>
#include <omp.h>
#include "smithwaterman.hpp"
#include "data.hpp"
#include "ltr.hpp"
//#include "checkwithsubstrings.hpp"
#include <map>
using namespace std;

string create_complement(const string& sequence){
  string s, c;
  map<string, string> corr;
  corr["A"]="T";
  corr["G"]="C";
  corr["C"]="G";
  corr["T"]="A";
  for(int i=sequence.length()-1; i>=0; --i){
    s=s+corr[sequence.substr(i, 1)];
  }
  return s;
}


int main(int argc, char** argv){

  int i, j, i_max, i_read, i_LTR, bait_length;
  if(argc<7){
    return -1;
  }
  string name, fileName(*(argv+1)), baitFileName(*(argv+5));  
  ifstream in(fileName);
  istream *input;
  if(in.is_open()){
    input=&in;
    name=fileName.substr(0, fileName.rfind("."));
  }else{
    input=&cin;
    name=fileName;
  }
  
  string fastqName, dataName;
  fastqName=name+".fastq";
  dataName=name+".txt";
  ofstream fastqOut(fastqName);
  ofstream dataOut(dataName);
  
  double cigarCeiling=boost::lexical_cast<double>(*(argv+2));
  double smithWatermanThreshold=boost::lexical_cast<double>(*(argv+3));
  int minimalTrimmedLength=boost::lexical_cast<int>(*(argv+4));
  //  int subStringLength=boost::lexical_cast<int>(*(argv+5));
  //  double subStringThreshold=boost::lexical_cast<double>(*(argv+6));
  bait_length=boost::lexical_cast<double>(*(argv+6));
  dataOut << "# Cigar value ceiling:      " << cigarCeiling << "\n";
  dataOut << "# Smith-Waterman threshold: " << smithWatermanThreshold << "\n";
  dataOut << "# Minimal trimmed length:   " << minimalTrimmedLength << "\n\n";
  // dataOut << "# Substring length:   " << subStringLength << "\n\n";
  // dataOut << "# Substring threshold:   " << subStringThreshold << "\n\n";
  
  

  ifstream inBait(baitFileName);
  if(!inBait.is_open()){
    return -1;
  }
  string line, bait_left, bait_right, bait_left_complement, bait_right_complement;
 
  vector<LTR> LTRs;
  while(getline(inBait, line)){
    if(line.length()>0 && line.substr(0, 1)!=">"){
      bait_left=line.substr(0, bait_length);
      bait_right=line.substr(line.length()-bait_length);
      bait_left_complement=create_complement(bait_left);
      bait_right_complement=create_complement(bait_right);
      LTRs.push_back(LTR(bait_left, -1));
      LTRs.push_back(LTR(bait_right, 1));
      LTRs.push_back(LTR(bait_left_complement, 1));
      LTRs.push_back(LTR(bait_right_complement, -1));
    }
  }
  inBait.close();
  
  // for(i=0; i<LTRs.size(); ++i)
  // std::cout << LTRs[i].sequence << " " << LTRs[i].direction << "\n";  
  // return 0;
 // LTRs.push_back(LTR("TGTGGGGAAAAGCAAGAGAG", -1));
 // LTRs.push_back(LTR("AGGGGCAACCCACCCCTACA", 1));
 // LTRs.push_back(LTR("TGTAGGGGTGGGTTGCCCCT", -1));
 // LTRs.push_back(LTR("CTCTCTTGCTTTTCCCCACA", 1));

  
  SmithWatermanResult smithWatermanResult[2*LTRs.size()];
  SAMData samData1, samData2;
  double score, maxScore, subStringProportion;
  Pair pair;
  string line1, line2, trimmedRead[2*LTRs.size()], trimmedQuality[2*LTRs.size()];
  int trimmedPosition[2*LTRs.size()];
  int i_pair=0;
  while(getline(*input, line1) && getline(*input, line2)){
    samData1.set(line1);
    samData2.set(line2);
    pair.set(samData1, samData2);
    if(samData1.cigarValue<=cigarCeiling || samData2.cigarValue<=cigarCeiling){
#pragma omp parallel for private (subStringProportion)
      for(i=0; i<LTRs.size()*2; ++i){
	//	subStringProportion=check_with_substrings(LTRs[i/2].sequence, pair[i%2].sequence, subStringLength);
	//	if(subStringProportion>=subStringThreshold){
	  smithwaterman(LTRs[i/2].sequence, pair[i%2].sequence, smithWatermanResult[i]);
	  getTrimmedValues(smithWatermanResult[i], pair[i%2], LTRs[i/2].direction, trimmedRead[i], trimmedQuality[i], trimmedPosition[i]);
	  //	}else{
	  // trimmedRead[i]="";
	  //	}
      }
      i_max=-1;
      maxScore-0;
      for(i=0; i<LTRs.size()*2; ++i){
	if(trimmedRead[i].length()>=minimalTrimmedLength){
	  score=smithWatermanResult[i].relativeScore;
	  if(score>=smithWatermanThreshold){
	    if(score>maxScore){
	      i_max=i;
	      maxScore=score;
	    }
	  }
	}
      }
      if(i_max>=0){
	i_read=i%2;
	i_LTR=i/2;

        cout << "pair: " << pair.name << " " << trimmedRead[i_max].length() << "\n";
	
	fastqOut << "@" << pair.name << "\n";
	fastqOut << trimmedRead[i_max] << "\n";
	fastqOut << "+\n";
	fastqOut << trimmedQuality[i_max] << "\n";
	
	dataOut << pair.name  << " " << i_read << " " << pair[i_read].chromosome << " " << pair[i_read].position+trimmedPosition[i_max] << " " << trimmedRead[i_max] << "   " << pair[0].chromosome << " " << pair[0].position << " " << pair[0].sequence << " " << pair[1].chromosome << " " << pair[1].position << " " << pair[1].sequence << "\n";
      }
    }
    ++i_pair;
    if((i_pair % 10000) ==0){
      cout << i_pair << "\n";
    }
  }
  
  fastqOut.close();
  dataOut.close();
  return 0; 
}
