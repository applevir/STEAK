#include "smithwaterman.hpp"
#include "ssw_cpp.h"
#include <iostream>
#include "string.h"
#include <boost/concept_check.hpp>
#include "samdata.hpp"
using namespace std;

void getTrimmedValues(const SmithWatermanResult& smithWatermanResult, const Read& read, int direction, std::string& trimmedRead, std::string& trimmedQuality, int& trimmedPosition){
  if(direction<0){
    trimmedRead=read.sequence.substr(0, smithWatermanResult.referenceStart);
    trimmedQuality=read.phred.substr(0, smithWatermanResult.referenceStart);
    trimmedPosition=0;
  }else{
    trimmedRead=read.sequence.substr(smithWatermanResult.referenceEnd+1);
    trimmedQuality=read.phred.substr(smithWatermanResult.referenceEnd+1);
    trimmedPosition=smithWatermanResult.referenceEnd+1;
  }
}


int smithwaterman(const std::string& shortSequence, const std::string& longSequence, SmithWatermanResult& result){
  StripedSmithWaterman::Aligner aligner;
  StripedSmithWaterman::Filter filter;
  StripedSmithWaterman::Alignment alignment;
  aligner.Align(shortSequence.c_str(), longSequence.c_str(), longSequence.size(), filter, &alignment);

  result.score=alignment.sw_score;
  result.relativeScore=((double)result.score)/2/shortSequence.length();
  result.referenceStart=alignment.ref_begin;
  result.referenceEnd=alignment.ref_end;
  result.queryStart=alignment.query_begin;
  result.queryEnd=alignment.query_end;
  result.n_mismatches=alignment.mismatches;
  result.cigarString=alignment.cigar_string;

  return 0; 
}
